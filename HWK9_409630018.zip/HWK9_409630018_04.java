package Week9;

import java.io.*;

public class HWK9_409630018_04 {

    public static void main(String[] args) throws IOException {
        String[] names = {"Peter", "Paul", "Mary", "Joe", "Cathy", "Samuel"};
        double[] scores = {88.5, 47.9, 90.3, 77.5, 65.8, 92.3};
        writeToBinaryFile("D:/Data/scores.bin", names, scores);
        readFromBinaryFile("D:/Data/scores.bin");
    }

    public static void writeToBinaryFile(String fName, String[] names, double[] scores) throws IOException {
        // 以二進位格式，運用byte stream 將names[], scores[]陣列內容逐對寫入檔案(c:/Data/scores.bin)
        // [檔案內容] (6)(Peter)(88.5)(Paul)(47.9).... 
        // <注意>: 上述[檔案內容]中的()只是示意符號，不會真的出現在scores.bin中 

        FileOutputStream fos = new FileOutputStream(fName);
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeInt(names.length); // 6
        // DIY here
        for (int i = 0; i < names.length; i++) {
            dos.writeUTF(names[i]);
            dos.writeDouble(scores[i]);
        }
        dos.close();
    }

    public static void readFromBinaryFile(String fName) throws IOException {
        // 讀取並印出二進位檔案(c:/Data/scores.bin)內容，再將其印出
        // 格式請參考[程式輸出]

        FileInputStream fis = new FileInputStream(fName);
        // DIY here
        DataInputStream dis = new DataInputStream(fis);
        int dr = dis.readInt();
        for (int i = 0; i < dr; i++) {
            System.out.print(dis.readUTF() + "\t");
            System.out.println(dis.readDouble());
        }
    }
}
/* [程式輸出]
Peter   88.5
Paul    47.9
Mary    90.3
Joe     77.5
Cathy   65.8
Samuel  92.3
 */
