package Week9;

import java.io.*;
import java.util.Arrays;

public class HWK9_409630018_02 {

    public static void main(String[] args) throws IOException {
        String ipFilename = "D:/Data/input-2.txt";
        String opFilename = "D:/Data/output-2.txt";
        try ( BufferedReader br = new BufferedReader(new FileReader(ipFilename));  BufferedWriter bw = new BufferedWriter(new FileWriter(opFilename))) {
            String aLine;
            while ((aLine = br.readLine()) != null) {
                String[] s = aLine.split("\t");
                //= aLine.split("\\s+");不管中間的空格直接分
                int cnt = 0;
                for (int i = 0; i < s.length; i++) {
                    if (!s[i].equals(" ") || !s[i].equals("\t") || !s[i].equals("")) {
                        cnt++;
                    }
                }
                String[] s1 = new String[cnt];
                int cnt1 = 0;
                for (int i = 0; i < s.length; i++) {
                    if (!s[i].equals(" ") || !s[i].equals("\t") || !s[i].equals("")) {
                        s1[cnt1] = s[i];
                        cnt1++;
                    }
                }
                for (int i = 0; i < s1.length - 1; i++) {
                    bw.write(s1[i] + ",");
                    System.out.print(s1[i] + ",");
                }
                if (!s1[s1.length - 1].equals("none")) {
                    bw.write(s1[s1.length - 1]);
                    System.out.print(s1[s1.length - 1]);
                }
                bw.newLine();
                System.out.println("");
         /* while((aLine=br.readLine())!=null){助教版本
                //arr=(aLine.split("\\s+"));
                //arr:[Peter, Male, 62156565]
                //arr:[Mary, Femal, 78236456, maternity, leave]
                //arr:[Joe, Male, 0800-092-000]
                //System.out.println("arr:"+Arrays.toString(arr));
                ss="";
                for(int i=0;i<arr.length;i++){
                    if(i==arr.length-1)
                    ss+=arr[i];
                else
                    ss+=arr[i]+",";
                }
                System.out.println("str:"+ss);
                bw.newLine();
            }*/
            }
            br.close();
            bw.close();
        }
    }

}
