package Week9;

import java.io.*;
import java.util.Scanner;

public class HWK9_409630018_03 {

    public static void main(String[] args) throws IOException {
        Scanner cin = new Scanner(System.in);
        System.out.print("baseDir = D:/Data\n"
                + "picture name = ");
        String a = cin.next();
        try ( FileInputStream fis = new FileInputStream("D:/Data/" + a);  FileOutputStream fos = new FileOutputStream("D:/Data/pic_bak.jpg");) {
            int i;
            int cnt = 0;
            while ((i = fis.read()) != -1) {
                fos.write(i);
                cnt++;
            }
            System.out.println("... copy complete (pic_bak.jpg)");
            System.out.println("#bytes = " + cnt);
            fis.close();
            fos.close();
        }

    }
}
//[參考執行過程]
//baseDir = c:/Data (直接印出即可)
//picture name = pic.jpg (使用者輸入)
//... copy complete (pic_bak.jpg)
//#bytes = ???? 
