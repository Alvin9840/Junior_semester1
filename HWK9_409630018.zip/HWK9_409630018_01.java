package Week9;

/*
<c:/Data/output.txt>: 欄位寬度10,10,13,10
Peter		Male		6215656
Mary		Female  	78236456		Note
Joe		Male		0800-092-000

 */
import java.io.*;
import java.util.ArrayList;

public class HWK9_409630018_01 {

    public static void main(String[] args) throws IOException {
        String ipFilename = "D:/Data/input.csv";
        String opFilename = "D:/Data/output.txt";
        try ( BufferedReader br = new BufferedReader(new FileReader(ipFilename));  BufferedWriter bw = new BufferedWriter(new FileWriter(opFilename))) {
            String aLine;
            while ((aLine = br.readLine()) != null) {
                String[] s = aLine.split(",");
                String[] s1 = new String[4];
                for (int i = 0; i < s1.length; i++) {
                    if (i >= s.length || s[i].equals(" ")) {
                        s1[i] = "none";
                    } else {
                        s1[i] = s[i];
                    }
                }
                bw.write(String.format("%s\t%s\t%s\t%s", s1[0], s1[1], s1[2], s1[3]));
                bw.newLine();

                System.out.printf("%s\t%s\t%s\t%s", s1[0], s1[1], s1[2], s1[3]);
                System.out.println("");
            }

            br.close();
            bw.close();
        }
    }
}
