package Week11;

import java.io.*;
import java.util.Scanner;

public class HWK11_409630018_02 {

    /*
    static String s = "#Peter Male 34500\n"+
                "#Mary Female 53667.8\n"+
                "#Killer Male 44333"; 
     */
    static String s = """
                      #Peter Male 43500
                      #Mary Female 53667.8
                      #Killer Male 44333""";

    public static void main(String[] args) throws IOException {
        parseByScanner();
        System.out.println("----------------------");
        parseByStreamTokenizer();
    }

    public static void parseByStreamTokenizer() throws IOException {
        StreamTokenizer st = new StreamTokenizer(new StringReader(s));

        int state = 0;
        while (st.nextToken() != StreamTokenizer.TT_EOF) {
            switch (state) {//狀態機
                case 0:
                    if (st.ttype == '#') {
                        System.out.print('@');
                        state++;
                    }
                    break;
                case 1:
                    if (st.ttype == StreamTokenizer.TT_WORD) {
                        System.out.print("<" + st.sval + ">");
                        state++;
                    }
                    break;
                case 2:
                    if (st.sval.equals("Male") || st.sval.equals("Female")) {
                        System.out.print("<" + (st.sval.equals("Male") ? true : false) + ">");
                        state++;
                    }
                    break;
                case 3:
                    if (st.ttype == StreamTokenizer.TT_NUMBER) {
                        System.out.print("<" + (int)st.nval + ">\n");
                        state = 0;
                    }
                    break;
            }
            new StringReader(s).close();
        }
    }

    public static void parseByScanner() throws IOException {
        StringReader sr = new StringReader(s);
        Scanner cin = new Scanner(sr);
        while (cin.hasNext()) {
            // #Peter Male 34500
            String name = cin.next().substring(1); // 去除"#"
            boolean gender = cin.next().equals("Male");
            double salary = cin.nextDouble();
            // @<Peter><Male><34500>
            System.out.printf("@<%s><%s><%d>\n", name, gender, ((int) salary));
        }
        sr.close();
    }
}
/*
(1) 先執行一遍(會呼叫parseByScanner())，觀察其結果。
(2) 修改main()中的程式碼，使其也呼叫parseByStreamTokenizer()函數
(3) 使用StreamTokenizer概念完成parseByStreamTokenizer()函數，產生與(1)相同之結果。
[程式輸出]
@<Peter><true><43500>
@<Mary><false><53667>
@<Killer><true><44333>
 */
