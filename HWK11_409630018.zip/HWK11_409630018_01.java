package Week11;

import java.io.*;
import java.util.*;

class Member {

    int ID;
    String nickName;
    String eMail;
    ArrayList<Integer> followWhom;

    Member() {
    }

    Member(int id, String name, String em) {
        ID = id;
        nickName = name;
        eMail = em;
        followWhom = new ArrayList<>();
    }

    void addFollowee(String fo) {
        // DIY: 
        // 例如，若fo="1002,1003"，表示他有關注其他二位成員，其編號分別是1002,1003
        //      將"1002,1003"剖析轉為數字1002,1003，逐一加入followWhom串列中
        String[] s = fo.split(",");
        for (String i : s) {
            followWhom.add(Integer.parseInt(i));
        }
    }

    @Override
    public String toString() {
        return ID + " " + nickName + " " + eMail + " " + followWhom;
    }
}

public class HWK11_409630018_01 {

    public static void main(String[] args) throws Exception {
        ArrayList<Member> memberList = new ArrayList<>();
        // DIY here，讀取D:/Data/follow_me.txt，產生member物件，並將其存入memberList中
        // 印出memberList
        try ( FileReader fr = new FileReader("D:/Data/follow_me.csv");  BufferedReader br = new BufferedReader(fr);) {
            br.readLine();//先跳過第一行
            String aLine;
            while ((aLine = br.readLine()) != null) {
//              String[] ss1 = aLine.split(",\\(");
                String[] ss = aLine.split(",");
                Member m = new Member(Integer.parseInt(ss[0]), ss[1], ss[2]);

                if (ss.length > 3) {//郵件後面的編號
                    for (int i = 3; i < ss.length; i++) {
                        String s = ss[i];
                        m.addFollowee(s);
                    }
                }
                memberList.add(m);
            }
        }
        for (Member m : memberList) {//程式輸出
            System.out.println(m.toString());
        }
    }
}
/*
每一行對應至一個Member物件，將其產生後，再加入memberList中。
[程式輸出]
1001 Peter peter@mail.tku.com [1002, 1003]
1002 Mary mary@gmail.com [1002, 1003, 1004]
1003 Paul paul@mail.yahoo.com []
1004 Joe joe@outlook.com [1001, 1002]
 */
