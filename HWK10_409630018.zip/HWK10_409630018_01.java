package Week10;

import java.io.*;
import javax.swing.*;

public class HWK10_409630018_01 {

    public static void main(String[] args) throws Exception {
        String baseDir = "D:/Data";
        JFileChooser chooser = new JFileChooser(baseDir);

        int code = chooser.showDialog(null, "Choose Src File");
        if (code == JFileChooser.APPROVE_OPTION) {
            File srcFile = chooser.getSelectedFile();
            System.out.println("Input: " + srcFile);

            try ( BufferedReader br = new BufferedReader(new FileReader(srcFile));  BufferedWriter bw = new BufferedWriter(new FileWriter("d:/Data/output.txt"));) {
                String i;
                while ((i = br.readLine()) != null) {
                    System.out.println(i);
                    bw.write(i);
                    bw.newLine();
                }
            }

        } else if (code == JFileChooser.CANCEL_OPTION) {
            System.out.println("Bye!");
        } else {
            System.out.println("Error!");
        }
        System.out.println("Completed");
    }
}
/*    public static void main(String[] args) throws FileNotFoundException, IOException {
        //String srcFile = args[0], destiFile = args[1] ;
        //String srcFile = "C:\\Users\\407630069\\Documents\\NetBeansProjects\\JavaApplication1\\src\\input1.txt";
        //String destiFile="C:\\Users\\407630069\\Documents\\NetBeansProjects\\JavaApplication1\\src\\output1.txt" ;
        String baseDir = "d:/node-v4.4.2";
        JFileChooser chooser1 = new JFileChooser(baseDir);
        JFileChooser chooser2 = new JFileChooser(baseDir);
        File src=getFile(chooser1);
        File des=getFile(chooser2);
        
        File fin =src;
        if  (!fin.exists()) {
            System.out.println(fin+":來源檔不存在") ;
            System.exit(0) ;
        }
        File fout =des ;
        if  (fout.exists()) {
            System.out.print(des+":目的檔已存在，要覆寫嗎?(y/n)") ;
            if  (new Scanner(System.in).next().equalsIgnoreCase("n"))
                System.exit(0) ;
        }
        FileReader fr = new FileReader(fin) ;
        FileWriter fw = new FileWriter(fout) ;
        
        
        char[] buf  = new char[(int)fin.length()] ; //???I?M?I
        fr.read(buf);fw.write(buf);fr.close(); fw.close();  
        
    }
    
    public static  File getFile(JFileChooser chooser1){
        File srcFile=null;
        int code=chooser1.showDialog(null, "Choose Src File");
        if(code ==JFileChooser.APPROVE_OPTION){
            srcFile=chooser1.getSelectedFile();
            
            System.out.println(srcFile);
        }
        else if(code==JFileChooser.CANCEL_OPTION){
            System.out.println("Bye!");
        }
        else{
            System.out.println("error");
        }
        return srcFile;
    }
}
*/