package Week10;

import java.io.*;
import java.util.*;
import javax.swing.JFileChooser;

public class HWK10_409630018_02 {

    public static void main(String[] args) throws Exception {
        Scanner cin = new Scanner(System.in);

        String baseDir = "d:/Data";
        System.out.print("<Dir Copy>\nsrc dir: ");
        String srcName = cin.next();
        File srcDir = new File(srcName);

        String destiName = "d:/Data/desti";
        File destiDir = new File(destiName);

        if (!srcDir.exists()) {
            System.out.println(srcName + " error!");
            System.exit(0);
        }
        if (!destiDir.exists()) {
            destiDir.mkdirs();
        }

        System.out.print("file type: ");
        String s = cin.next();
        System.out.println("....copy....");
        dirCopy(srcDir, destiDir, s);
        System.out.println("\n<<<copy complete>>>");
    }

    public static void dirCopy(File srcDir, File destiDir, String suffix) throws Exception {
        if (srcDir.isFile() || destiDir.isFile()) {
            return;
        }
        File[] flist = srcDir.listFiles();
        // 過濾檔案可參考listFiles(FileFilter filter), listFiles(FilenameFilter filter)
        // --- DIY here, 使用FileInputStream+FileOutputStream複製檔案 ---
        for (int i = 0; i < flist.length; i++) {
            String[] s = flist[i].getName().split("\\.");
            if (s[1].equals(suffix)) {
                System.out.print(flist[i].getName() + " ");
                FileInputStream fis = new FileInputStream(flist[i].getAbsoluteFile());
                FileOutputStream fos = new FileOutputStream(destiDir.getAbsolutePath() + "/" + flist[i].getName());
                int a;
                while ((a = fis.read()) != -1) {
                    fos.write(a);
                }
                fis.close();
                fos.close();
            }
        }
    }
}
