package Week10;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

class Staff {

    String name;
    boolean gender;
    double salary;

    Staff(String a, boolean b, double c) {
        name = a;
        gender = b;
        salary = c;
    }

    // DIY, 自行加上toString(), 格式自訂
    public String toString() {
        String s = "";
        if (gender == true) {
            s = "Male";
        }
        if (gender == false) {
            s = "Female";
        }
        return String.format("%s %s %.2f", name, s, salary);
    }
}

public class HWK10_409630018_03 {

    public static void main(String[] args) throws IOException {
        Staff[] recs = {new Staff("John", true, 38000.5), new Staff("Mary", false, 125000.49)};
        String filename = "d:/Data/data.txt";

        System.out.println("------ Write to text file -------");
        PrintWriter pw = new PrintWriter(new FileWriter(filename));
        writeStaffToText(pw, recs);

        System.out.println("------ Read from text file -------");
        ArrayList<Staff> staffList = readStaffFromText(filename);
//        System.out.println(staffList);
    }

    public static void writeStaffToText(PrintWriter pw, Staff[] recs) { // 沒有例外丟出
        for (int i = 0; i < recs.length; i++) {
            pw.printf("<%s><%s><%.2f>\n", recs[i].name, (recs[i].gender ? "M" : "F"),
                    recs[i].salary);
            System.out.printf("<%s><%s><%.2f>\n", recs[i].name, (recs[i].gender ? "M" : "F"),
                    recs[i].salary);
        }

        pw.close();
    }

    public static ArrayList<Staff> readStaffFromText(String filename) throws IOException {
        ArrayList<Staff> staffList = new ArrayList<>();
        // DIY
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String aLine;
        while ((aLine = br.readLine()) != null) {
            aLine = aLine.replace("><", " ").replace("<", "").replace(">", "");
            System.out.println(aLine);
            String[] s = aLine.split(" ");
            String name = s[0];
            boolean gender = (s[1].equals("M") ? true : false);
            double salary = Double.parseDouble(s[2]);
            Staff sf = new Staff(name, gender, salary);
            staffList.add(sf);
        }
        return staffList;
    }
}
