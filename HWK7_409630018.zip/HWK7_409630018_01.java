package Week7;

import java.util.*;

class MyPoint {

    int x, y;

    MyPoint(int a, int b) {
        x = a;
        y = b;
    }

    public String toString() {
        return "(" + x + "," + y + ")";
    }
}

class MPComparator implements Comparator {

    public int compare(Object a, Object b) {
        MyPoint a1 = (MyPoint) a;
        MyPoint b1 = (MyPoint) b;
        if (a1.x > b1.x) {
            return 1;
        } else if (a1.x == b1.x) {
            if (a1.y > b1.y) {
                return 1;
            }
        }
        return -1;
    }

    public boolean equals(Object O) {
        return this == O;
    }
}

public class HWK7_409630018_01 {

    public static void main(String[] args) {
        MyPoint[] mps = {new MyPoint(3, 6), new MyPoint(1, 2), new MyPoint(-1, -1), new MyPoint(-8, 9)};
        Arrays.sort(mps, new MPComparator());
        // … 自行用for印出msp //(-1,-1) (1, 2) ( 3,6) (-8,9)
        for (MyPoint i : mps) {
            System.out.print("(" + i.x + "," + i.y + ")");
        }
    }
}
