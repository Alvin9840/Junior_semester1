package Week7;

interface StackError {

    int OK = 0, STACK_FULL = 1, STACK_EMPTY = 2, OUT_OF_MEMEORY = 3, UNKNOWN = 4;
}

class StackX<T> {

    int errFlag = StackError.OK;
    T[] data;
    int top = -1;

    public StackX(int size) {
        if (size < 1) {
            size = 5;
        }
        data = (T[]) new Object[size];
    }

    public void push(T o) {
        if (top == data.length - 1) // Exception Handling
        {
            errFlag = StackError.STACK_FULL;
        } else {
            data[++top] = o;
        }
    }

    public T pop() {
        if (top < 0) {
            errFlag = StackError.STACK_EMPTY;
            return null;
        } else {
            return data[top--];
        }
    }
}

public class HWK7_409630018_02 {

    public static void main(String[] args) {
        StackX<Integer> alertMsg = new StackX(10); //使用堆疊儲存警告訊息(ID)
        for (int i = 0; i < 30; i++) {
            if (Math.random() > 0.5) {
                alertMsg.push(i);
                if (alertMsg.errFlag != StackError.OK) {
                    if (alertMsg.errFlag == StackError.STACK_FULL) {
                        StackX<Integer> a = new StackX(alertMsg.data.length * 2);
                        for (int j : alertMsg.data) {
                            a.push(j);
                        }
                        alertMsg = a;
                        alertMsg.errFlag = StackError.OK;
                        alertMsg.push(i);
                    }
                }
                System.out.println("push():" + i);
            } else {
                Object obj = alertMsg.pop();
                // DIY here
                if (alertMsg.errFlag == StackError.STACK_EMPTY) {
                    System.out.println("STACK_EMPTY");
                    alertMsg.errFlag = StackError.OK;
                    continue;
                } else {
                    int x = (Integer) obj;
                    System.out.println("pop():" + x);
                }
            }
        }
    }
}
