package Week1;

class Point {

    double x, y;

    void set(double a, double b) {
        this.x = a;
        this.y = b;
    }

    double distOnLine(Point p2, Point p3) {
        double a, b;//a是斜率,b是參數
        a = (this.y - p2.y) / (this.x - p2.x);
        b = -a * this.x + this.y;
        if (a * p3.x + b == p3.y) {
            if (dist(this, p2) > dist(p2, p3) && dist(this, p2) > dist(this, p3)) {
                return dist(this, p2);
            } else if (dist(p2, p3) > dist(this, p2) && dist(p2, p3) > dist(this, p3)) {
                return dist(p2, p3);
            } else if (dist(this, p3) > dist(p2, p3) && dist(this, p3) > dist(this, p2)) {
                return dist(this, p3);
            }
        }
        return -1;
    }

    double dist(Point p1, Point p2) {
        return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
    }
}

public class HWK1_409630018_01 {

    public static void main(String[] args) {
        Point p1 = new Point(), p2 = new Point(), p3 = new Point();
        p1.set(5, 3);
        p2.set(3, 0);
        p3.set(4, 1);
        System.out.println("length of line = " + p1.distOnLine(p2, p3));
        Point p4 = new Point();
        p4.set(1, -2);
        System.out.println("length of line = " + p2.distOnLine(p3, p4));
    }

}
