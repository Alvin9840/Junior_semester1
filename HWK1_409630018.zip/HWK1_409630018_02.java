package Week1;

import java.util.*;

class Rect {

    int x, y, w, h;

    void set(int a, int b, int c, int d) {
        x = a;
        y = b;
        w = c;
        h = d;
    }

    void draw(String a) {
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                if (i == 0 || i == h - 1) {
                    System.out.print("@");
                } else if (j == 0 || j == w - 1) {
                    System.out.print("@");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }

    double overlapArea(Rect r2) {
        double s = 0;
        int a = this.x - r2.x;//>0 == r1在r2右邊
        int b = this.y - r2.y;//>0 == r1在r2上面
        int c, d;
        if (a > 0 && b > 0) {//r1在r2右上方
            c = r2.x + r2.w - this.x;
            d = r2.y - (this.y - this.h);
            s = Math.abs(c * d);
        } else if (a > 0 && b < 0) {//r1在r2右下方
            c = this.x - (r2.x + r2.w);
            d = this.y - (r2.y - r2.h);
            s = Math.abs(c * d);
        } else if (a < 0 && b > 0) {//r1在r2左上方
            c = r2.x - (this.x + this.w);
            d = r2.y - (this.y - this.h);
            s = Math.abs(c * d);
        } else if (a < 0 && b < 0) {//r1在r2左下方
            c = this.x + this.w - r2.x;
            d = this.y - (r2.y - r2.h);
            s = Math.abs(c * d);
        }

        return s;
    }

    public String toString() {
        return "(" + x + "," + y + "," + w + "," + h + ")";
    }
}

public class HWK1_409630018_02 {

    public static void main(String[] args) {
        Rect r1 = new Rect();
        r1.set(1, 4, 4, 3);
        System.out.println("r1 = " + r1);
        r1.draw("@");

        Rect r2 = new Rect();
        r2.set(2, 7, 5, 5);
        double overlapArea = r1.overlapArea(r2);
        System.out.println("overlapArea = " + overlapArea);
    }
}
