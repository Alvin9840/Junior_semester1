package Week5;

import java.util.Arrays;

class StudentRec {

    int id;
    String name;
    int[] score;

    StudentRec(int a, String b, int[] c) {
        this.id = a;
        this.name = b;
        this.score = Arrays.copyOf(c, c.length);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof StudentRec)) {
            return false;
        }
        StudentRec a = (StudentRec) obj;
        Boolean sc = true;
        for (int i = 0; i < this.score.length; i++) {
            if (this.score[i] != a.score[i]) {
                sc = false;
                break;
            }
        }
        return (this.id == a.id && this.name.equals(a.name) && sc); // DIY, 自行修改
    }

    public String toString() {
        return String.format("(%d,%s,%s)", id, name, Arrays.toString(score));
    }
}

public class HWK5_409630018_01 {

    public static void main(String[] args) {
        int[] s1 = {77, 88, 99, 100}, s2 = {77, 88, 99, 100}, s3 = {77, 99, 100};
        String n1 = new String("Peter"), n2 = new String("Peter"), n3 = "Peter";
        StudentRec sr1 = new StudentRec(1001, n1, s1);
        StudentRec sr2 = new StudentRec(1001, n2, s2);
        StudentRec sr3 = new StudentRec(1001, n3, s3);
        System.out.println("sr1 = " + sr1);
        System.out.println("sr2 = " + sr2);
        System.out.println("sr3 = " + sr3);
        if (sr1.equals(sr2)) {
            System.out.println("sr1 equals to sr2"); // yes
        }
        if (sr1.equals(sr3)) {
            System.out.println("sr1 equals to sr3"); // no
        }
        if (sr1.equals(sr1)) {
            System.out.println("sr1 equals to sr1"); // yes
        }
        if (sr1.equals("Peter")) {
            System.out.println("sr1 equals to \"Peter\""); // no
        }
    }
}
