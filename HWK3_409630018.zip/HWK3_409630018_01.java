package Week3;

class Employee { //公司員工

    int ID;
    String name;

    void set(int id, String n) {
        this.ID = id;
        this.name = n;
    }
}

class Fulltime extends Employee { // 全職人員
    // int ID ;	String name ; 

    double baseSalary;
    int lenOfService;

    void set(int ID, String n, double baseSalary, int lenOfService) {
        super.set(ID, n);
        this.baseSalary = baseSalary;
        this.lenOfService = lenOfService;
    }

    double calSalary() {
        double s = 0;
        s += this.baseSalary * Math.pow(1.05, this.lenOfService - 1);
        if (s > (this.baseSalary * 2)) {
            return -1;
        } else {
            return s;
        }

    }

    public String toString() {
        return String.format("(%d,%s,%d,%d)\ncalSalary= %.2f", this.ID, this.name, (int)this.baseSalary, this.lenOfService, this.calSalary());
//        return "(" + this.ID + "," + this.name + "," + this.baseSalary + "," + this.lenOfService + ")";
    }
}

public class HWK3_409630018_01 {

    public static void main(String[] args) {
        Fulltime f = new Fulltime();
        f.set(1002, "Peter"); // OK ?
        f.baseSalary = 37300; // 比照碩士生基本薪資
        f.lenOfService = 5; // 年資5年
        System.out.println(f);
//        System.out.printf("%s%.2f", "calSalary = ", f.calSalary());
    }
}
