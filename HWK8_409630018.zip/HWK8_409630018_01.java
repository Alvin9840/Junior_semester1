package Week8;

import java.io.*;

public class HWK8_409630018_01 {

    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("D:/Data/input.txt");
        int c;
        int sp_cnt = 0, en_cnt = 0;
        while (true) {
            c = fr.read();
            if (c == -1) {
                break;
            }
            System.out.print((char) c);
            if (((char) c) == ' ') {
                sp_cnt++;
            }
            if (((char) c) == '\n') {
                en_cnt++;
            }
        }
        System.out.println("\n\nSpace = " + sp_cnt);
        System.out.println("Enter = " + en_cnt);
        fr.close();
    }
}
