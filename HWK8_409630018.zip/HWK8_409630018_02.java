package Week8;

import java.io.*;

public class HWK8_409630018_02 {

    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("D:/Data/input.txt");
        FileWriter fw = new FileWriter("D:/Data/output.txt");
        int c;
        while (true) {
            c = fr.read();
            if (c == -1) {
                break;
            }
            fw.write(c);
        }
        fr.close();
        fw.close();
    }
}
