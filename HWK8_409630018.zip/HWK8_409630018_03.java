package Week8;

import java.io.*;

public class HWK8_409630018_03 {

    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("D:/Data/input2.txt");
        FileWriter fw = new FileWriter("D:/Data/output2.txt");
        int c;
        int sp_cnt = 0;
        boolean brLock = false;//換行
        while (true) {
            c = fr.read();
            if (c == -1) {
                break;
            }

            if (((char) c) == ' ') {
                sp_cnt++;
            }
            if (((char) c) != ' ') {
                sp_cnt = 0;
            }
            if (brLock == true && ((char) c) != ' ') {
                brLock = false;
            }
            if (((char) c) == '\n') {
                brLock = true;
            }
            if (sp_cnt <= 1 && brLock == false) {
                fw.write(c);
            }
        }
        fr.close();
        fw.close();
    }
}
