package Week6;

import java.util.*;

class MyPoint {

    int x, y;

    MyPoint(int a, int b) {
        x = a;
        y = b;
    }

    public String toString() {
        return "(" + x + "," + y + ")";
    }
}

class MPComparator implements Comparator {

    public int compare(Object o1, Object o2) {
        MyPoint a = (MyPoint) o1;
        MyPoint b = (MyPoint) o2;
        if (a.x > b.x) {
            return 1;
        } else if (a.x == b.x) {
            if (a.y >= b.y) {
                return 1;
            }
        }
        return -1;
    }

    public boolean equals(Object o) {
        return this == o;
    }
}

public class HWK6_409630018_04 {

    public static void main(String[] args) {
        MyPoint[] mps = {new MyPoint(3, 6), new MyPoint(1, 2), new MyPoint(-1, -1), new MyPoint(-8, 9)};
        Arrays.sort(mps, new MPComparator());
        // … 自行用for印出msp //(-1,-1) (1, 2) ( 3,6) (-8,9)
        System.out.print("mps[]=[");
        for (MyPoint i : mps) {
            System.out.print(i);
        }
        System.out.print("]");
    }
}
