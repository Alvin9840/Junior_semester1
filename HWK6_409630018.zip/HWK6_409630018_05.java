package Week6;

import java.awt.Toolkit;

interface AlarmTimer {

    void alarm();
}

class TimeTool {

    static void startTimer(AlarmTimer timer, int duraction, int step) {
        //每隔step秒，timer會alarm一次，持續duraction秒
        try {
            for (int i = 0; i < (duraction / step); i++) {
                timer.alarm();
                Thread.sleep(step * 1000);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

class BeepWatch implements AlarmTimer {

    @Override
    public void alarm() {
        Toolkit.getDefaultToolkit().beep();
    }
}

class EchoWatch implements AlarmTimer {

    @Override
    public void alarm() {
        System.out.println("Wake up");
    }
}

public class HWK6_409630018_05 {

    public static void main(String[] args) {

        AlarmTimer bw = new BeepWatch();
        TimeTool.startTimer(bw, 20, 2);
        AlarmTimer ew = new EchoWatch();
        TimeTool.startTimer(ew, 10, 1);
    }

}
