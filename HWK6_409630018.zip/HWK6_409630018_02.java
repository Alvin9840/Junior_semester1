package Week6;

import java.awt.*;

interface Shape {

    double area();

    void draw(Graphics g);
}

class Circle implements Shape {

    double r;

    Circle(double r) {
        this.r = r;
    }

    public double area() {
        return Math.PI * r * r;
    }

    public void draw(Graphics g) {
//        畫出圓
    }
}

class Rect implements Shape {

    double w, h;

    Rect(double w, double h) {
        this.w = w;
        this.h = h;
    }

    public double area() {
        return w * h;
    }

    public void draw(Graphics g) {
//        畫出方形
    }
}

class PaintBoard {

    Shape[] shapes = new Shape[100];
    int cnt = 0;

    void add(Shape s) {
        shapes[cnt++] = s;
    }

    double calTotalArea() {
        double a = 0;
        for (int i = 0; i < this.cnt; i++) {
            a += shapes[i].area();
        }
        return a;
    }
}

public class HWK6_409630018_02 {

    public static void main(String[] args) {
        PaintBoard pb = new PaintBoard();
        pb.add(new Circle(3));
        pb.add(new Rect(9, 4));
        pb.add(new Circle(5.5));
        System.out.println("Total area= " + pb.calTotalArea());
    }
}
//程式輸出: Total area = 159.3075116533994
