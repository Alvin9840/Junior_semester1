package Week2;

class Time { // 以24小時進制儲存時間

    int h, m, s;

    // DIY: 自行完成所需建構式
    Time() {
    }

    Time(int h, int m, int s) {
        this.h = h;
        this.m = m;
        this.s = s;
    }

    Time(String a) {
        String[] b = a.split(" ");
        String x = new String();

        if (b.length > 1) {
            x = b[1];
        } else {
            x = b[0];
        }

        String[] c = x.split(":");
        this.h = Integer.parseInt(c[0]);
        this.m = Integer.parseInt(c[1]);
        this.s = Integer.parseInt(c[2]);
        if (b[0].equals("PM")) {
            this.h += 12;
        }
    }

    void show(String msg) {
        System.out.printf("%s%02d%s%02d%s%02d", msg, h, ":", m, ":", s); //可能需修改
        System.out.println();
    }
}

public class HWK2_409630018_03 {

    public static void main(String[] args) {

        Time t1 = new Time(15, 30, 20);
        Time t2 = new Time("18:5:50");
        Time t3 = new Time("AM 8:20:50");
        Time t4 = new Time("PM 7:10:40");
        t1.show("t1= ");
        t2.show("t2= ");
        t3.show("t3= ");
        t4.show("t4= ");
    }
}
/* [程式輸出]
15:30:20
18:05:50
08:20:50
19:10:40

 */
